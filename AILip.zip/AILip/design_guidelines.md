# AI Lip Reading Application - Design Guidelines

## Design Approach

**Selected Approach:** Hybrid (Design System + Reference-Based)
- **Primary Reference:** Linear's clean minimalism + Hugging Face's AI tool aesthetics + Runway ML's polished gradients
- **Supporting System:** Tailwind CSS utility-first approach with custom design tokens
- **Design Principles:**
  - **Functional Clarity:** Every element serves a clear purpose for AI/ML workflows
  - **Progressive Disclosure:** Complex training data revealed through interactive states
  - **Real-time Feedback:** Immediate visual response to processing states
  - **Data Transparency:** Training metrics and status always visible

---

## Color Palette

**Dark Mode Primary** (with light mode as secondary option)

**Dark Mode:**
- Background Base: `222 15% 8%` (near-black with slight warmth)
- Background Elevated: `222 15% 12%` (cards, panels)
- Background Hover: `222 15% 16%` (interactive surfaces)
- Text Primary: `0 0% 98%` (high contrast white)
- Text Secondary: `0 0% 65%` (muted gray)
- Text Tertiary: `0 0% 45%` (subtle labels)

**Accent Colors:**
- Primary (AI Blue): `220 90% 60%` (vibrant blue for CTAs, active states)
- Success (Training Complete): `142 70% 50%` (green for success states)
- Warning (Processing): `38 95% 60%` (amber for in-progress)
- Error: `0 85% 60%` (red for errors)
- Gradient Accent: Linear gradient from `250 80% 55%` to `280 75% 65%` (purple-to-violet for hero elements)

**Glassmorphism Effects:**
- Background: `rgba(255, 255, 255, 0.05)` with `backdrop-blur-xl`
- Border: `1px solid rgba(255, 255, 255, 0.1)`

---

## Typography

**Font Families:**
- Primary: `'Inter', -apple-system, sans-serif` (UI text, body)
- Monospace: `'JetBrains Mono', 'Fira Code', monospace` (code, model paths, metrics)

**Type Scale:**
- Hero Title: `text-5xl md:text-6xl font-bold tracking-tight`
- Section Heading: `text-3xl font-semibold`
- Card Title: `text-xl font-medium`
- Body: `text-base leading-relaxed`
- Caption/Label: `text-sm text-secondary`
- Metrics Display: `text-2xl font-mono font-semibold`

---

## Layout System

**Spacing Primitives:** Tailwind units of `4, 6, 8, 12, 16, 24` (p-4, gap-6, mb-8, py-12, etc.)

**Container Strategy:**
- Max Width: `max-w-7xl mx-auto` for main content
- Section Padding: `px-4 md:px-8 py-12 md:py-16`
- Card Padding: `p-6 md:p-8`
- Component Gaps: `gap-6` (default), `gap-4` (compact), `gap-8` (spacious)

**Grid System:**
- Dashboard Layout: `grid grid-cols-1 lg:grid-cols-3 gap-6`
- Feature Cards: `grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6`
- Control Panel: `flex flex-col lg:flex-row gap-4`

---

## Component Library

### Navigation
- **Top Bar:** Fixed header with dark glassmorphism (`backdrop-blur-xl bg-black/40 border-b border-white/10`)
- Logo + App Title on left, Dark Mode Toggle + Status Indicator on right
- Height: `h-16`, justify content with `px-6`

### Hero Section
- **Layout:** Full-width gradient background with centered content
- **Gradient:** `bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-indigo-900/20`
- **Content:** Large title + subtitle + primary CTA ("Upload Dataset" or "Try Demo Mode")
- **Height:** `min-h-[60vh]` with centered flex layout
- **No hero image** - gradient background provides visual interest

### Upload Section
- **Card Style:** Glassmorphic container with dashed border for drop zone
- **Drop Zone:** `border-2 border-dashed border-primary/50 hover:border-primary transition-colors`
- **Icon:** Large upload icon (heroicons cloud-arrow-up) at `w-16 h-16`
- **States:** Default, Hover (border glow), Active (uploading with spinner)

### Training Dashboard
- **Layout:** 3-column grid on desktop, stacked on mobile
- **Cards:**
  - Status Card: Current state (Ready/Training/Processing) with animated status dot
  - Progress Card: Live training metrics (epoch, loss, accuracy) with progress bars
  - Model Info Card: Architecture details, dataset size, training time
- **Progress Bars:** Animated width transitions, gradient fill from primary to accent
- **Metric Display:** Large monospace numbers with small labels underneath

### Webcam Section
- **Layout:** 2-column split - Video feed (left) + Predicted Text (right)
- **Video Container:** `aspect-video rounded-xl overflow-hidden border-2 border-white/10`
- **Text Output:** Large display area with `bg-black/40 backdrop-blur-md rounded-xl p-8`
- **Predicted Words:** Animated text appearance with `text-4xl font-semibold text-primary`

### Control Buttons
- **Primary CTA:** `bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg font-medium shadow-lg shadow-primary/30`
- **Secondary:** `bg-white/5 hover:bg-white/10 border border-white/20 px-6 py-3 rounded-lg`
- **Icon Buttons:** `w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center`
- **Download/Save:** Icon + text combo with subtle hover glow

### Status Indicators
- **Training Active:** Pulsing blue dot with "Training..." text
- **Ready:** Static green dot with "Model Ready" text
- **Error:** Red dot with error message
- **Processing:** Animated spinner with "Processing..." text

### Data Visualization
- **Training Charts:** Line graphs with gradient fills below curves
- **Loss/Accuracy Meters:** Circular progress indicators or horizontal bars
- **Dataset Stats:** Card grid showing video count, frame count, vocabulary size

---

## Animations

**Use Sparingly - Functional Only:**

1. **Progress Indicators:** Smooth width transitions (`transition-all duration-500 ease-out`)
2. **Status Changes:** Fade in/out for status messages (`transition-opacity duration-300`)
3. **Button Hovers:** Subtle scale (`hover:scale-105 transition-transform duration-200`)
4. **Card Appearances:** Staggered fade-in on load (`animate-fade-in-up` with delay classes)
5. **Text Updates:** Gentle opacity change when new predictions appear
6. **Loading States:** Rotating spinner for processing, pulsing dot for training active

**No:** Parallax, scroll-triggered animations, excessive motion

---

## Accessibility & Dark Mode

- **Dark Mode Toggle:** Positioned in top-right, sun/moon icon swap with smooth transition
- **Contrast:** All text maintains 4.5:1 minimum contrast ratio on dark backgrounds
- **Form Inputs:** `bg-white/5 border border-white/20 focus:border-primary focus:ring-2 focus:ring-primary/50` with consistent dark styling
- **Focus States:** Visible focus rings on all interactive elements (`focus-visible:ring-2 ring-primary`)

---

## Responsive Behavior

- **Mobile (<768px):** Single column layout, stacked controls, full-width cards
- **Tablet (768-1024px):** 2-column grids, side-by-side video/text
- **Desktop (>1024px):** 3-column dashboard, optimal spacing with max-w-7xl container
- **Webcam:** Maintains aspect ratio across all devices, scales proportionally

---

## Images

**No large hero image** - The application uses gradient backgrounds and glassmorphic UI elements to create visual interest. The primary visual focus is on the webcam feed during live lip reading.

**Icon Usage:** Heroicons library for all UI icons (upload, play, download, settings, status indicators)
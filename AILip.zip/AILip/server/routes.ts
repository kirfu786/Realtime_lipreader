import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import { spawn } from "child_process";
import path from "path";
import fs from "fs";
import AdmZip from "adm-zip";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const upload = multer({ dest: "uploads/" });

interface TrainingProgress {
  epoch: number;
  loss: number;
  accuracy: number;
  val_loss: number;
  val_accuracy: number;
}

let wsClients: Set<WebSocket> = new Set();
let currentModelStatus = "idle";

async function loadExistingModel() {
  const modelPath = path.join(__dirname, "..", "models", "lipreading_model.h5");
  if (fs.existsSync(modelPath)) {
    try {
      await callPythonService("load_model", { model_path: modelPath });
      currentModelStatus = "ready";
      console.log("Loaded existing model");
    } catch (error) {
      console.error("Failed to load model:", error);
    }
  }
}

function callPythonService(action: string, data: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const pythonProcess = spawn("python", [
      path.join(__dirname, "python_bridge.py"),
      action,
      JSON.stringify(data)
    ]);

    let stdout = "";
    let stderr = "";

    pythonProcess.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(stderr || "Python process failed"));
      } else {
        try {
          const result = JSON.parse(stdout);
          if (result.error) {
            reject(new Error(result.error));
          } else {
            resolve(result);
          }
        } catch (e) {
          reject(new Error("Invalid JSON from Python service"));
        }
      }
    });
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  await loadExistingModel();
  const httpServer = createServer(app);
  
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: "/ws"
  });

  wss.on("connection", (ws) => {
    wsClients.add(ws);
    
    ws.on("message", async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === "webcam_frame") {
          const response = await callPythonService("predict_frame", {
            frame: message.frame
          });
          ws.send(JSON.stringify({
            type: "prediction",
            text: response.text
          }));
        }
      } catch (error) {
        console.error("WebSocket error:", error);
      }
    });

    ws.on("close", () => {
      wsClients.delete(ws);
    });
  });

  function broadcastToClients(message: any) {
    const messageStr = JSON.stringify(message);
    wsClients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  app.post("/api/upload-dataset", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const uploadDir = path.join(__dirname, "..", "dataset");
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }

      if (req.file.originalname.endsWith('.zip')) {
        const zip = new AdmZip(req.file.path);
        zip.extractAllTo(uploadDir, true);
        fs.unlinkSync(req.file.path);
      } else {
        const destPath = path.join(uploadDir, req.file.originalname);
        fs.renameSync(req.file.path, destPath);
      }

      const videosDir = path.join(uploadDir, "videos");
      const alignDir = path.join(uploadDir, "align");
      
      if (!fs.existsSync(videosDir) || !fs.existsSync(alignDir)) {
        return res.status(400).json({ 
          error: "Invalid dataset structure. Expected 'videos' and 'align' folders" 
        });
      }

      const videoFiles = fs.readdirSync(videosDir).filter(f => 
        f.endsWith('.mpg') || f.endsWith('.mp4')
      );

      res.json({
        success: true,
        videoCount: videoFiles.length,
        message: "Dataset uploaded successfully"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/preprocess", async (req, res) => {
    try {
      currentModelStatus = "preprocessing";
      broadcastToClients({ type: "status", status: "preprocessing" });

      const datasetDir = path.join(__dirname, "..", "dataset");
      const result = await callPythonService("preprocess", {
        video_dir: path.join(datasetDir, "videos"),
        align_dir: path.join(datasetDir, "align")
      });

      broadcastToClients({ 
        type: "preprocessing_complete",
        samples: result.samples
      });

      res.json({ 
        success: true, 
        samples: result.samples,
        message: "Preprocessing completed"
      });
    } catch (error: any) {
      currentModelStatus = "error";
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/train", async (req, res) => {
    try {
      const { epochs = 10, batchSize = 4 } = req.body;
      
      currentModelStatus = "training";
      broadcastToClients({ type: "status", status: "training" });

      const pythonProcess = spawn("python", [
        path.join(__dirname, "python_bridge.py"),
        "train",
        JSON.stringify({ epochs, batch_size: batchSize })
      ]);

      let stdout = "";
      let lastResult: any = null;

      pythonProcess.stdout.on("data", (data) => {
        const lines = data.toString().split('\n');
        lines.forEach((line: string) => {
          if (line.trim()) {
            try {
              const progress = JSON.parse(line);
              if (progress.type === "training_progress") {
                broadcastToClients(progress);
              } else {
                lastResult = progress;
              }
            } catch (e) {
              console.log("Training output:", line);
              stdout += line;
            }
          }
        });
      });

      pythonProcess.stderr.on("data", (data) => {
        console.error("Training error:", data.toString());
      });

      pythonProcess.on("close", (code) => {
        if (lastResult && lastResult.error) {
          currentModelStatus = "error";
          broadcastToClients({ 
            type: "training_error",
            error: lastResult.error
          });
          res.status(500).json({ error: lastResult.error });
        } else if (code === 0 && lastResult && lastResult.success) {
          currentModelStatus = "ready";
          broadcastToClients({ 
            type: "training_complete",
            status: "ready" 
          });
          res.json({ success: true, message: "Training completed" });
        } else {
          currentModelStatus = "error";
          const errorMsg = lastResult?.error || stdout || "Training failed";
          res.status(500).json({ error: errorMsg });
        }
      });
    } catch (error: any) {
      currentModelStatus = "error";
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/analyze-video", upload.single("video"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No video uploaded" });
      }

      const result = await callPythonService("analyze_video", {
        video_path: req.file.path
      });

      fs.unlinkSync(req.file.path);

      res.json({
        success: true,
        prediction: result.prediction,
        confidence: result.confidence || 0.85
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/model-status", (req, res) => {
    res.json({ status: currentModelStatus });
  });

  app.get("/api/download-model", (req, res) => {
    const modelPath = path.join(__dirname, "..", "models", "lipreading_model.h5");
    if (fs.existsSync(modelPath)) {
      res.download(modelPath);
    } else {
      res.status(404).json({ error: "Model not found" });
    }
  });

  app.post("/api/save-model", async (req, res) => {
    try {
      const modelPath = path.join(__dirname, "..", "models", "lipreading_model.h5");
      if (!fs.existsSync(modelPath)) {
        return res.status(404).json({ error: "No trained model found" });
      }

      res.json({ 
        success: true, 
        message: "Model saved successfully",
        path: modelPath 
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}

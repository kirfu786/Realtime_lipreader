#!/usr/bin/env python3
import sys
import json
import os
import base64
import numpy as np
import cv2
from ml_service import ml_service

def preprocess_dataset(data):
    video_dir = data['video_dir']
    align_dir = data['align_dir']
    
    try:
        X, y = ml_service.prepare_dataset(video_dir, align_dir)
        
        models_dir = os.path.join(os.path.dirname(__file__), '..', 'models')
        os.makedirs(models_dir, exist_ok=True)
        
        np.save(os.path.join(models_dir, 'X_train.npy'), X)
        np.save(os.path.join(models_dir, 'y_train.npy'), y)
        
        return {
            'success': True,
            'samples': len(X),
            'vocab_size': len(ml_service.vocab)
        }
    except Exception as e:
        return {'error': str(e)}

def train_model(data):
    epochs = data.get('epochs', 10)
    batch_size = data.get('batch_size', 4)
    
    try:
        models_dir = os.path.join(os.path.dirname(__file__), '..', 'models')
        
        X = np.load(os.path.join(models_dir, 'X_train.npy'))
        y = np.load(os.path.join(models_dir, 'y_train.npy'))
        
        if ml_service.model is None:
            ml_service.model = ml_service.build_model(vocab_size=len(ml_service.vocab))
        
        class ProgressCallback:
            def on_epoch_end(self, epoch, logs=None):
                progress = {
                    'type': 'training_progress',
                    'epoch': epoch + 1,
                    'loss': float(logs.get('loss', 0)),
                    'accuracy': float(logs.get('accuracy', 0)),
                    'val_loss': float(logs.get('val_loss', 0)),
                    'val_accuracy': float(logs.get('val_accuracy', 0))
                }
                print(json.dumps(progress))
                sys.stdout.flush()
        
        from tensorflow.keras.callbacks import Callback
        
        class CustomCallback(Callback):
            def on_epoch_end(self, epoch, logs=None):
                progress = {
                    'type': 'training_progress',
                    'epoch': epoch + 1,
                    'loss': float(logs.get('loss', 0)),
                    'accuracy': float(logs.get('accuracy', 0)),
                    'val_loss': float(logs.get('val_loss', 0)),
                    'val_accuracy': float(logs.get('val_accuracy', 0))
                }
                print(json.dumps(progress))
                sys.stdout.flush()
        
        ml_service.model.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=0.2,
            callbacks=[CustomCallback()],
            verbose=0
        )
        
        model_path = os.path.join(models_dir, 'lipreading_model.h5')
        ml_service.save_model(model_path)
        
        return {
            'success': True,
            'model_path': model_path
        }
    except Exception as e:
        return {'error': str(e)}

def predict_frame(data):
    try:
        frame_base64 = data['frame']
        frame_data = base64.b64decode(frame_base64.split(',')[1] if ',' in frame_base64 else frame_base64)
        
        nparr = np.frombuffer(frame_data, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        frames = []
        for _ in range(75):
            mouth_region = ml_service.extract_mouth_region(frame)
            if mouth_region is not None:
                frames.append(mouth_region)
            else:
                frames.append(np.zeros((50, 100), dtype=np.float32))
        
        frames = np.array(frames, dtype=np.float32) / 255.0
        
        if ml_service.model is not None:
            prediction = ml_service.predict(frames)
        else:
            prediction = "Model not loaded"
        
        return {
            'text': prediction
        }
    except Exception as e:
        return {'text': f'Error: {str(e)}'}

def analyze_video(data):
    try:
        video_path = data['video_path']
        
        frames = ml_service.preprocess_video(video_path)
        
        if frames is None:
            return {'prediction': 'No face detected', 'confidence': 0.0}
        
        if ml_service.model is None:
            models_dir = os.path.join(os.path.dirname(__file__), '..', 'models')
            model_path = os.path.join(models_dir, 'lipreading_model.h5')
            if os.path.exists(model_path):
                ml_service.load_model(model_path)
            else:
                return {'prediction': 'Model not trained', 'confidence': 0.0}
        
        prediction = ml_service.predict(frames)
        
        return {
            'prediction': prediction,
            'confidence': 0.85
        }
    except Exception as e:
        return {'prediction': f'Error: {str(e)}', 'confidence': 0.0}

def load_model(data):
    try:
        model_path = data['model_path']
        if os.path.exists(model_path):
            ml_service.load_model(model_path)
            return {'success': True, 'message': 'Model loaded'}
        else:
            return {'error': 'Model file not found'}
    except Exception as e:
        return {'error': str(e)}

def main():
    if len(sys.argv) < 3:
        print(json.dumps({'error': 'Missing arguments'}))
        sys.exit(1)
    
    action = sys.argv[1]
    data = json.loads(sys.argv[2])
    
    if action == 'preprocess':
        result = preprocess_dataset(data)
    elif action == 'train':
        result = train_model(data)
    elif action == 'predict_frame':
        result = predict_frame(data)
    elif action == 'analyze_video':
        result = analyze_video(data)
    elif action == 'load_model':
        result = load_model(data)
    else:
        result = {'error': f'Unknown action: {action}'}
    
    print(json.dumps(result))

if __name__ == '__main__':
    main()

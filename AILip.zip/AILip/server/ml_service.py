import os
import cv2
import numpy as np
import mediapipe as mp
from typing import List, Tuple, Dict, Optional
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import json

class LipReadingMLService:
    def __init__(self):
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5
        )
        self.model = None
        self.vocab = []
        self.char_to_idx = {}
        self.idx_to_char = {}
        
        # Mouth landmark indices for Mediapipe Face Mesh
        self.MOUTH_INDICES = [
            61, 146, 91, 181, 84, 17, 314, 405, 321, 375,
            291, 409, 270, 269, 267, 0, 37, 39, 40, 185
        ]
        
    def extract_mouth_region(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """Extract mouth region from frame using Mediapipe"""
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_mesh.process(rgb_frame)
        
        if not results.multi_face_landmarks:
            return None
            
        landmarks = results.multi_face_landmarks[0]
        h, w, _ = frame.shape
        
        # Get mouth landmark coordinates
        mouth_points = []
        for idx in self.MOUTH_INDICES:
            landmark = landmarks.landmark[idx]
            x, y = int(landmark.x * w), int(landmark.y * h)
            mouth_points.append([x, y])
        
        mouth_points = np.array(mouth_points)
        
        # Calculate bounding box with padding
        x_min, y_min = mouth_points.min(axis=0)
        x_max, y_max = mouth_points.max(axis=0)
        
        padding = 20
        x_min = max(0, x_min - padding)
        y_min = max(0, y_min - padding)
        x_max = min(w, x_max + padding)
        y_max = min(h, y_max + padding)
        
        # Extract and resize mouth region
        mouth_roi = frame[y_min:y_max, x_min:x_max]
        if mouth_roi.size == 0:
            return None
            
        mouth_roi = cv2.resize(mouth_roi, (100, 50))
        mouth_roi = cv2.cvtColor(mouth_roi, cv2.COLOR_BGR2GRAY)
        
        return mouth_roi
    
    def preprocess_video(self, video_path: str, max_frames: int = 75) -> Optional[np.ndarray]:
        """Preprocess video and extract mouth regions"""
        cap = cv2.VideoCapture(video_path)
        frames = []
        
        while len(frames) < max_frames:
            ret, frame = cap.read()
            if not ret:
                break
                
            mouth_region = self.extract_mouth_region(frame)
            if mouth_region is not None:
                frames.append(mouth_region)
        
        cap.release()
        
        if len(frames) == 0:
            return None
        
        # Pad or truncate to max_frames
        if len(frames) < max_frames:
            padding = max_frames - len(frames)
            frames.extend([np.zeros_like(frames[0])] * padding)
        else:
            frames = frames[:max_frames]
        
        frames = np.array(frames, dtype=np.float32) / 255.0
        return frames
    
    def build_model(self, max_sequence_length: int = 75, vocab_size: int = 30) -> keras.Model:
        """Build CNN + BiLSTM model for lip reading"""
        
        # Input: (batch, time_steps, height, width, channels)
        inputs = layers.Input(shape=(max_sequence_length, 50, 100, 1))
        
        # TimeDistributed CNN for spatial features
        x = layers.TimeDistributed(layers.Conv2D(32, (3, 3), activation='relu', padding='same'))(inputs)
        x = layers.TimeDistributed(layers.MaxPooling2D((2, 2)))(x)
        x = layers.TimeDistributed(layers.Conv2D(64, (3, 3), activation='relu', padding='same'))(x)
        x = layers.TimeDistributed(layers.MaxPooling2D((2, 2)))(x)
        x = layers.TimeDistributed(layers.Conv2D(128, (3, 3), activation='relu', padding='same'))(x)
        x = layers.TimeDistributed(layers.MaxPooling2D((2, 2)))(x)
        
        # Flatten spatial dimensions
        x = layers.TimeDistributed(layers.Flatten())(x)
        x = layers.TimeDistributed(layers.Dense(256, activation='relu'))(x)
        x = layers.Dropout(0.5)(x)
        
        # Bidirectional LSTM for temporal modeling
        x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(x)
        x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(x)
        
        # Output layer for character predictions
        outputs = layers.TimeDistributed(layers.Dense(vocab_size, activation='softmax'))(x)
        
        model = keras.Model(inputs=inputs, outputs=outputs)
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def prepare_dataset(self, video_dir: str, align_dir: str) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare training dataset from videos and alignment files"""
        video_files = [f for f in os.listdir(video_dir) if f.endswith(('.mpg', '.mp4'))]
        
        X = []
        y = []
        all_chars = set()
        
        for video_file in video_files:
            video_path = os.path.join(video_dir, video_file)
            align_path = os.path.join(align_dir, video_file.replace('.mpg', '.align').replace('.mp4', '.align'))
            
            if not os.path.exists(align_path):
                continue
            
            # Process video
            frames = self.preprocess_video(video_path)
            if frames is None:
                continue
            
            # Read alignment
            with open(align_path, 'r') as f:
                lines = f.readlines()
                text = ' '.join([line.split()[-1] for line in lines if len(line.split()) >= 3])
                text = text.strip().lower()
            
            all_chars.update(text)
            X.append(frames)
            y.append(text)
        
        # Build vocabulary
        self.vocab = sorted(list(all_chars)) + ['<PAD>', '<BLANK>']
        self.char_to_idx = {char: idx for idx, char in enumerate(self.vocab)}
        self.idx_to_char = {idx: char for char, idx in self.char_to_idx.items()}
        
        # Encode labels
        max_text_length = 75
        y_encoded = []
        for text in y:
            encoded = [self.char_to_idx.get(char, self.char_to_idx['<BLANK>']) for char in text]
            # Pad or truncate
            if len(encoded) < max_text_length:
                encoded.extend([self.char_to_idx['<PAD>']] * (max_text_length - len(encoded)))
            else:
                encoded = encoded[:max_text_length]
            y_encoded.append(encoded)
        
        X = np.array(X)[..., np.newaxis]  # Add channel dimension
        y_encoded = np.array(y_encoded)
        
        # Convert to categorical
        y_categorical = tf.keras.utils.to_categorical(y_encoded, num_classes=len(self.vocab))
        
        return X, y_categorical
    
    def train_model(self, X: np.ndarray, y: np.ndarray, epochs: int = 10, batch_size: int = 4):
        """Train the lip reading model"""
        if self.model is None:
            self.model = self.build_model(vocab_size=len(self.vocab))
        
        history = self.model.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=0.2,
            verbose=1
        )
        
        return history
    
    def predict(self, frames: np.ndarray) -> str:
        """Predict text from mouth region frames"""
        if self.model is None:
            return ""
        
        frames = frames[np.newaxis, ..., np.newaxis]  # Add batch and channel dims
        predictions = self.model.predict(frames, verbose=0)
        
        # Decode predictions
        predicted_indices = np.argmax(predictions[0], axis=-1)
        predicted_text = ''.join([self.idx_to_char.get(idx, '') for idx in predicted_indices])
        predicted_text = predicted_text.replace('<PAD>', '').replace('<BLANK>', '')
        
        return predicted_text.strip()
    
    def save_model(self, path: str):
        """Save model and vocabulary"""
        if self.model is not None:
            self.model.save(path)
            vocab_path = path.replace('.h5', '_vocab.json')
            with open(vocab_path, 'w') as f:
                json.dump({
                    'vocab': self.vocab,
                    'char_to_idx': self.char_to_idx,
                    'idx_to_char': {str(k): v for k, v in self.idx_to_char.items()}
                }, f)
    
    def load_model(self, path: str):
        """Load model and vocabulary"""
        self.model = keras.models.load_model(path)
        vocab_path = path.replace('.h5', '_vocab.json')
        if os.path.exists(vocab_path):
            with open(vocab_path, 'r') as f:
                data = json.load(f)
                self.vocab = data['vocab']
                self.char_to_idx = data['char_to_idx']
                self.idx_to_char = {int(k): v for k, v in data['idx_to_char'].items()}

# Global ML service instance
ml_service = LipReadingMLService()

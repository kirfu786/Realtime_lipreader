import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { UploadSection } from "@/components/UploadSection";
import { ControlPanel } from "@/components/ControlPanel";
import { TrainingDashboard } from "@/components/TrainingDashboard";
import { WebcamSection } from "@/components/WebcamSection";
import { ModelActions } from "@/components/ModelActions";
import { VideoAnalysis } from "@/components/VideoAnalysis";

export default function Home() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [modelStatus, setModelStatus] = useState<"idle" | "training" | "ready" | "error" | "processing">("idle");
  const [predictedText, setPredictedText] = useState("");
  const [videoPrediction, setVideoPrediction] = useState("");
  const [isAnalyzingVideo, setIsAnalyzingVideo] = useState(false);
  const [trainingMetrics, setTrainingMetrics] = useState<{
    epoch: number;
    totalEpochs: number;
    loss: number;
    accuracy: number;
    status: "idle" | "training" | "ready" | "error" | "processing";
  }>({
    epoch: 0,
    totalEpochs: 50,
    loss: 1.0,
    accuracy: 0,
    status: "idle",
  });

  const { toast } = useToast();
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
    
    ws.onopen = () => {
      console.log('WebSocket connected');
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'training_progress') {
        setTrainingMetrics({
          epoch: data.epoch,
          totalEpochs: trainingMetrics.totalEpochs,
          loss: data.loss,
          accuracy: data.accuracy,
          status: "training"
        });
      } else if (data.type === 'training_complete') {
        setModelStatus("ready");
        setTrainingMetrics(prev => ({ ...prev, status: "ready" }));
        toast({
          title: "Training Complete",
          description: "Model is ready for predictions",
        });
      } else if (data.type === 'preprocessing_complete') {
        toast({
          title: "Preprocessing Complete",
          description: `Processed ${data.samples} samples`,
        });
        setModelStatus("idle");
      } else if (data.type === 'prediction') {
        setPredictedText(data.text);
      } else if (data.type === 'status') {
        setModelStatus(data.status);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    wsRef.current = ws;

    return () => {
      ws.close();
    };
  }, []);

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      const response = await fetch('/api/upload-dataset', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Dataset Uploaded",
        description: `Successfully uploaded ${data.videoCount} videos`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const preprocessMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/preprocess', { method: 'POST' });
      if (!response.ok) throw new Error('Preprocessing failed');
      return response.json();
    },
    onSuccess: () => {
      setModelStatus("processing");
    },
    onError: (error: Error) => {
      toast({
        title: "Preprocessing Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const trainMutation = useMutation({
    mutationFn: async (params: { epochs: number; batchSize: number }) => {
      const response = await fetch('/api/train', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (!response.ok) throw new Error('Training failed');
      return response.json();
    },
    onSuccess: () => {
      setModelStatus("training");
    },
    onError: (error: Error) => {
      toast({
        title: "Training Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const analyzeVideoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('video', file);
      const response = await fetch('/api/analyze-video', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Analysis failed');
      return response.json();
    },
    onSuccess: (data) => {
      setVideoPrediction(data.prediction);
      setIsAnalyzingVideo(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsAnalyzingVideo(false);
    }
  });

  const handleUpload = (file: File) => {
    setUploadedFile(file);
    uploadMutation.mutate(file);
  };

  const handlePreprocess = () => {
    preprocessMutation.mutate();
  };

  const handleTrain = () => {
    setTrainingMetrics({
      epoch: 0,
      totalEpochs: 10,
      loss: 1.0,
      accuracy: 0,
      status: "training",
    });
    trainMutation.mutate({ epochs: 10, batchSize: 4 });
  };

  const handleDemoMode = () => {
    setModelStatus("ready");
    setTrainingMetrics({
      epoch: 10,
      totalEpochs: 10,
      loss: 0.15,
      accuracy: 0.92,
      status: "ready",
    });
    toast({
      title: "Demo Mode Activated",
      description: "Using pretrained model for predictions",
    });
  };

  const handleWebcamToggle = (active: boolean, frameData?: string) => {
    if (active && frameData && wsRef.current) {
      wsRef.current.send(JSON.stringify({
        type: 'webcam_frame',
        frame: frameData
      }));
    } else {
      setPredictedText("");
    }
  };

  const handleVideoAnalysis = (file: File) => {
    setIsAnalyzingVideo(true);
    setVideoPrediction("");
    analyzeVideoMutation.mutate(file);
  };

  const handleDownload = async () => {
    try {
      const response = await fetch('/api/download-model');
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'lipreading_model.h5';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Model Downloaded",
        description: "Model saved to your device",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Could not download model",
        variant: "destructive",
      });
    }
  };

  const handleSaveToGoogleDrive = () => {
    toast({
      title: "Google Drive Integration",
      description: "This feature requires Google Drive setup",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <HeroSection
        onStartDemo={handleDemoMode}
      />
      
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-12 space-y-12">
        <UploadSection onUpload={handleUpload} />
        
        <ControlPanel
          onPreprocess={handlePreprocess}
          onTrain={handleTrain}
          onDemoMode={handleDemoMode}
          disabled={!uploadedFile && modelStatus !== "idle"}
        />
        
        <TrainingDashboard
          metrics={trainingMetrics}
          modelInfo={{
            architecture: "CNN+BiLSTM",
            datasetSize: uploadedFile ? 1200 : 0,
            trainingTime: modelStatus === "ready" ? "2h 34m" : undefined,
          }}
        />
        
        <WebcamSection
          predictedText={predictedText}
          onToggleWebcam={handleWebcamToggle}
        />

        <VideoAnalysis
          modelReady={modelStatus === "ready"}
          predictedText={videoPrediction}
          isAnalyzing={isAnalyzingVideo}
          onAnalyze={handleVideoAnalysis}
        />
        
        <ModelActions
          modelReady={modelStatus === "ready"}
          onDownload={handleDownload}
          onSaveToGoogleDrive={handleSaveToGoogleDrive}
        />
      </main>
    </div>
  );
}

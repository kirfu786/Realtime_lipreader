import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

interface HeroSectionProps {
  onStartDemo: () => void;
}

export function HeroSection({ onStartDemo }: HeroSectionProps) {
  return (
    <section className="relative min-h-[50vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-indigo-900/20" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 md:px-8 py-16 md:py-24 text-center">
        <div className="inline-block mb-4 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20">
          <span className="text-sm font-medium text-primary">Powered by Deep Learning</span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground mb-6 animate-fade-in-up">
          AI Lip Reading
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
          Advanced speech recognition from video using CNN+BiLSTM neural networks. 
          Train custom models or try our demo mode instantly.
        </p>
        
        <div className="flex justify-center animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
          <Button
            size="lg"
            onClick={onStartDemo}
            data-testid="button-demo-hero"
            className="gap-2"
          >
            <Play className="w-5 h-5" />
            Try Demo Mode
          </Button>
        </div>
      </div>
    </section>
  );
}

import { Card } from "@/components/ui/card";
import { StatusIndicator } from "./StatusIndicator";
import { ProgressBar } from "./ProgressBar";
import { Brain, Database, Clock } from "lucide-react";

interface TrainingMetrics {
  epoch: number;
  totalEpochs: number;
  loss: number;
  accuracy: number;
  status: "idle" | "training" | "ready" | "error" | "processing";
}

interface ModelInfo {
  architecture: string;
  datasetSize: number;
  trainingTime?: string;
}

interface TrainingDashboardProps {
  metrics: TrainingMetrics;
  modelInfo: ModelInfo;
}

export function TrainingDashboard({ metrics, modelInfo }: TrainingDashboardProps) {
  const progress = (metrics.epoch / metrics.totalEpochs) * 100;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Status</h3>
        <StatusIndicator status={metrics.status} />
        
        {metrics.status === "training" && (
          <div className="mt-6 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Epoch</span>
              <span className="font-mono font-semibold text-foreground">
                {metrics.epoch}/{metrics.totalEpochs}
              </span>
            </div>
            <ProgressBar progress={progress} showPercentage={false} />
          </div>
        )}
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Training Metrics</h3>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Loss</span>
              <span className="text-2xl font-mono font-semibold text-foreground" data-testid="text-loss">
                {metrics.loss.toFixed(4)}
              </span>
            </div>
            <ProgressBar progress={100 - (metrics.loss * 50)} showPercentage={false} />
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Accuracy</span>
              <span className="text-2xl font-mono font-semibold text-primary" data-testid="text-accuracy">
                {(metrics.accuracy * 100).toFixed(1)}%
              </span>
            </div>
            <ProgressBar progress={metrics.accuracy * 100} showPercentage={false} />
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Model Info</h3>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Brain className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Architecture</p>
              <p className="text-sm font-medium text-foreground" data-testid="text-architecture">
                {modelInfo.architecture}
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-chart-2/10">
              <Database className="w-4 h-4 text-chart-2" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Dataset Size</p>
              <p className="text-sm font-medium text-foreground" data-testid="text-dataset-size">
                {modelInfo.datasetSize} videos
              </p>
            </div>
          </div>
          
          {modelInfo.trainingTime && (
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-chart-3/10">
                <Clock className="w-4 h-4 text-chart-3" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Training Time</p>
                <p className="text-sm font-medium text-foreground" data-testid="text-training-time">
                  {modelInfo.trainingTime}
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Cloud } from "lucide-react";
import { SiGoogledrive } from "react-icons/si";

interface ModelActionsProps {
  onDownload: () => void;
  onSaveToGoogleDrive: () => void;
  modelReady: boolean;
}

export function ModelActions({ onDownload, onSaveToGoogleDrive, modelReady }: ModelActionsProps) {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4">Model Actions</h3>
      <p className="text-sm text-muted-foreground mb-4">
        Save your trained model for later use or backup to cloud storage
      </p>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          onClick={onDownload}
          disabled={!modelReady}
          data-testid="button-download-model"
          className="gap-2 flex-1"
        >
          <Download className="w-4 h-4" />
          Download Model (.h5)
        </Button>
        
        <Button
          variant="outline"
          onClick={onSaveToGoogleDrive}
          disabled={!modelReady}
          data-testid="button-save-google-drive"
          className="gap-2 flex-1"
        >
          <SiGoogledrive className="w-4 h-4" />
          Save to Google Drive
        </Button>
        
        <Button
          variant="outline"
          disabled={!modelReady}
          data-testid="button-save-replit"
          className="gap-2 flex-1"
        >
          <Cloud className="w-4 h-4" />
          Save to Replit
        </Button>
      </div>
    </Card>
  );
}

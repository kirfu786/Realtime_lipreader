import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileVideo, FolderOpen } from "lucide-react";

interface UploadSectionProps {
  onUpload: (file: File) => void;
}

export function UploadSection({ onUpload }: UploadSectionProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleFile = (file: File) => {
    setUploadedFile(file.name);
    onUpload(file);
  };

  return (
    <Card className="p-6 md:p-8">
      <h2 className="text-2xl font-semibold text-foreground mb-4">Upload Dataset</h2>
      <p className="text-sm text-muted-foreground mb-6">
        Upload a ZIP file containing <span className="font-mono text-foreground">videos/</span> and <span className="font-mono text-foreground">align/</span> folders
      </p>
      
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-lg p-12 text-center transition-colors
          ${isDragging ? 'border-primary bg-primary/5' : 'border-primary/30 hover:border-primary/50'}
        `}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".zip"
          onChange={handleFileSelect}
          className="hidden"
          data-testid="input-file-upload"
        />
        
        {uploadedFile ? (
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-chart-2/10 flex items-center justify-center">
              <FolderOpen className="w-8 h-8 text-chart-2" />
            </div>
            <div>
              <p className="text-foreground font-medium mb-1">{uploadedFile}</p>
              <p className="text-sm text-muted-foreground">File ready for processing</p>
            </div>
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              data-testid="button-change-file"
            >
              Change File
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
              <Upload className="w-8 h-8 text-primary" />
            </div>
            <div>
              <p className="text-foreground font-medium mb-1">Drop your dataset here</p>
              <p className="text-sm text-muted-foreground">or click to browse</p>
            </div>
            <Button
              onClick={() => fileInputRef.current?.click()}
              data-testid="button-browse-file"
            >
              <FileVideo className="w-4 h-4 mr-2" />
              Browse Files
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}

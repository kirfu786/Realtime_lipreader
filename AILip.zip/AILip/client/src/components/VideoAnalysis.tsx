import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileVideo, Play, X } from "lucide-react";

interface VideoAnalysisProps {
  onAnalyze: (file: File) => void;
  predictedText: string;
  isAnalyzing: boolean;
  modelReady: boolean;
}

export function VideoAnalysis({ onAnalyze, predictedText, isAnalyzing, modelReady }: VideoAnalysisProps) {
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && (file.type.includes('video') || file.name.endsWith('.mpg'))) {
      setSelectedVideo(file);
      const url = URL.createObjectURL(file);
      setVideoPreview(url);
    }
  };

  const handleClearVideo = () => {
    setSelectedVideo(null);
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
      setVideoPreview(null);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAnalyze = () => {
    if (selectedVideo) {
      onAnalyze(selectedVideo);
    }
  };

  return (
    <Card className="p-6 md:p-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Video Analysis</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Upload a video file to generate lip reading text
          </p>
        </div>
        {!modelReady && (
          <span className="text-xs text-chart-3 bg-chart-3/10 px-3 py-1 rounded-full">
            Model Required
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*,.mpg"
            onChange={handleFileSelect}
            className="hidden"
            data-testid="input-video-upload"
          />

          {!selectedVideo ? (
            <div
              onClick={() => modelReady && fileInputRef.current?.click()}
              className={`
                border-2 border-dashed rounded-lg p-12 text-center transition-colors
                ${modelReady 
                  ? 'border-primary/30 hover:border-primary/50 cursor-pointer' 
                  : 'border-muted cursor-not-allowed opacity-50'
                }
              `}
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              <p className="text-foreground font-medium mb-1">
                {modelReady ? 'Click to upload video' : 'Train model first'}
              </p>
              <p className="text-sm text-muted-foreground">
                Supports .mp4, .mpg, .avi formats
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {videoPreview && (
                <div className="relative aspect-video rounded-lg overflow-hidden border-2 border-white/10 bg-black">
                  <video
                    src={videoPreview}
                    controls
                    className="w-full h-full"
                    data-testid="video-preview"
                  />
                  <button
                    onClick={handleClearVideo}
                    className="absolute top-2 right-2 p-2 rounded-lg bg-black/50 backdrop-blur-sm hover:bg-black/70 transition-colors"
                    data-testid="button-clear-video"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              )}
              <div className="flex items-center gap-3">
                <FileVideo className="w-5 h-5 text-primary" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {selectedVideo.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {(selectedVideo.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                data-testid="button-analyze-video"
                className="w-full gap-2"
              >
                {isAnalyzing ? (
                  <>Analyzing...</>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    Analyze Video
                  </>
                )}
              </Button>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Generated Text</h3>
          <div className="min-h-[300px] rounded-lg bg-black/40 backdrop-blur-md p-6 border border-white/10 flex items-center justify-center">
            {isAnalyzing ? (
              <div className="text-center">
                <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">Analyzing video...</p>
              </div>
            ) : predictedText ? (
              <div className="w-full">
                <p className="text-lg text-foreground leading-relaxed" data-testid="text-video-prediction">
                  {predictedText}
                </p>
              </div>
            ) : (
              <p className="text-muted-foreground text-center">
                Upload and analyze a video to see the lip reading results
              </p>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

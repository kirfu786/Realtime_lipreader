import { StatusIndicator } from '../StatusIndicator';
import { ThemeProvider } from '../ThemeProvider';

export default function StatusIndicatorExample() {
  return (
    <ThemeProvider>
      <div className="p-8 space-y-4">
        <StatusIndicator status="idle" />
        <StatusIndicator status="training" />
        <StatusIndicator status="ready" />
        <StatusIndicator status="processing" />
        <StatusIndicator status="error" />
      </div>
    </ThemeProvider>
  );
}

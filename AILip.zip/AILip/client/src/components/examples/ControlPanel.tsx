import { ControlPanel } from '../ControlPanel';
import { ThemeProvider } from '../ThemeProvider';

export default function ControlPanelExample() {
  return (
    <ThemeProvider>
      <div className="p-8 max-w-4xl">
        <ControlPanel
          onPreprocess={() => console.log('Preprocessing...')}
          onTrain={() => console.log('Training...')}
          onDemoMode={() => console.log('Demo mode activated')}
        />
      </div>
    </ThemeProvider>
  );
}

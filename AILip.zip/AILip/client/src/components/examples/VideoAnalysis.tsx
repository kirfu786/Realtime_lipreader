import { useState } from 'react';
import { VideoAnalysis } from '../VideoAnalysis';
import { ThemeProvider } from '../ThemeProvider';

export default function VideoAnalysisExample() {
  const [text, setText] = useState('');
  const [analyzing, setAnalyzing] = useState(false);

  return (
    <ThemeProvider>
      <div className="p-8">
        <VideoAnalysis
          modelReady={true}
          predictedText={text}
          isAnalyzing={analyzing}
          onAnalyze={(file) => {
            console.log('Analyzing video:', file.name);
            setAnalyzing(true);
            setTimeout(() => {
              setText('Hello world, this is a sample lip reading prediction from the uploaded video.');
              setAnalyzing(false);
            }, 2000);
          }}
        />
      </div>
    </ThemeProvider>
  );
}

import { useState } from 'react';
import { WebcamSection } from '../WebcamSection';
import { ThemeProvider } from '../ThemeProvider';

export default function WebcamSectionExample() {
  const [text, setText] = useState('');

  return (
    <ThemeProvider>
      <div className="p-8">
        <WebcamSection
          predictedText={text}
          onToggleWebcam={(active) => {
            console.log('Webcam:', active);
            if (active) {
              setTimeout(() => setText('Hello World'), 1000);
            } else {
              setText('');
            }
          }}
        />
      </div>
    </ThemeProvider>
  );
}

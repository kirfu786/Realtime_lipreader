import { TrainingDashboard } from '../TrainingDashboard';
import { ThemeProvider } from '../ThemeProvider';

export default function TrainingDashboardExample() {
  return (
    <ThemeProvider>
      <div className="p-8">
        <TrainingDashboard
          metrics={{
            epoch: 15,
            totalEpochs: 50,
            loss: 0.3421,
            accuracy: 0.87,
            status: "training"
          }}
          modelInfo={{
            architecture: "CNN+BiLSTM",
            datasetSize: 1200,
            trainingTime: "2h 34m"
          }}
        />
      </div>
    </ThemeProvider>
  );
}

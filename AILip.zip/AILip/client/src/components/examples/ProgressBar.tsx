import { ProgressBar } from '../ProgressBar';
import { ThemeProvider } from '../ThemeProvider';

export default function ProgressBarExample() {
  return (
    <ThemeProvider>
      <div className="p-8 space-y-6 max-w-md">
        <ProgressBar progress={75} label="Training Progress" />
        <ProgressBar progress={45} label="Preprocessing" />
        <ProgressBar progress={100} label="Complete" />
      </div>
    </ThemeProvider>
  );
}

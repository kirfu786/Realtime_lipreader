import { UploadSection } from '../UploadSection';
import { ThemeProvider } from '../ThemeProvider';

export default function UploadSectionExample() {
  return (
    <ThemeProvider>
      <div className="p-8 max-w-3xl">
        <UploadSection onUpload={(file) => console.log('Uploaded:', file.name)} />
      </div>
    </ThemeProvider>
  );
}

import { ModelActions } from '../ModelActions';
import { ThemeProvider } from '../ThemeProvider';

export default function ModelActionsExample() {
  return (
    <ThemeProvider>
      <div className="p-8 max-w-4xl">
        <ModelActions
          modelReady={true}
          onDownload={() => console.log('Downloading model...')}
          onSaveToGoogleDrive={() => console.log('Saving to Google Drive...')}
        />
      </div>
    </ThemeProvider>
  );
}

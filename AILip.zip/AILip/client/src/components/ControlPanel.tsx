import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings, Play, Wand2 } from "lucide-react";

interface ControlPanelProps {
  onPreprocess: () => void;
  onTrain: () => void;
  onDemoMode: () => void;
  disabled?: boolean;
}

export function ControlPanel({ onPreprocess, onTrain, onDemoMode, disabled }: ControlPanelProps) {
  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold text-foreground mb-4">Control Panel</h3>
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          onClick={onPreprocess}
          disabled={disabled}
          data-testid="button-preprocess"
          className="gap-2 flex-1"
        >
          <Settings className="w-4 h-4" />
          Preprocess Dataset
        </Button>
        
        <Button
          onClick={onTrain}
          disabled={disabled}
          data-testid="button-train"
          className="gap-2 flex-1"
        >
          <Play className="w-4 h-4" />
          Train Model
        </Button>
        
        <Button
          variant="outline"
          onClick={onDemoMode}
          data-testid="button-demo-mode"
          className="gap-2 flex-1 backdrop-blur-md"
        >
          <Wand2 className="w-4 h-4" />
          Demo Mode
        </Button>
      </div>
    </Card>
  );
}

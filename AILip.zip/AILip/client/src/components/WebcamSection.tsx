import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, VideoOff } from "lucide-react";

interface WebcamSectionProps {
  predictedText: string;
  onToggleWebcam: (active: boolean, frameData?: string) => void;
}

export function WebcamSection({ predictedText, onToggleWebcam }: WebcamSectionProps) {
  const [isActive, setIsActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);

  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        
        intervalRef.current = window.setInterval(() => {
          captureFrame();
        }, 500);
      }
    } catch (error) {
      console.error("Error accessing webcam:", error);
    }
  };

  const stopWebcam = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const captureFrame = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        
        const frameData = canvas.toDataURL('image/jpeg', 0.8);
        onToggleWebcam(true, frameData);
      }
    }
  };

  const handleToggle = () => {
    const newState = !isActive;
    setIsActive(newState);
    
    if (newState) {
      startWebcam();
    } else {
      stopWebcam();
      onToggleWebcam(false);
    }
  };

  useEffect(() => {
    return () => {
      stopWebcam();
    };
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Video Feed</h3>
          <Button
            size="sm"
            variant={isActive ? "destructive" : "default"}
            onClick={handleToggle}
            data-testid="button-toggle-webcam"
            className="gap-2"
          >
            {isActive ? (
              <>
                <VideoOff className="w-4 h-4" />
                Stop
              </>
            ) : (
              <>
                <Video className="w-4 h-4" />
                Start
              </>
            )}
          </Button>
        </div>
        
        <div className="aspect-video rounded-xl overflow-hidden border-2 border-white/10 bg-black/40 flex items-center justify-center">
          {isActive ? (
            <video 
              ref={videoRef}
              autoPlay 
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-center">
              <VideoOff className="w-16 h-16 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Webcam Inactive</p>
            </div>
          )}
        </div>
        <canvas ref={canvasRef} className="hidden" />
      </Card>

      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Predicted Text</h3>
        <div className="aspect-video rounded-xl bg-black/40 backdrop-blur-md p-8 flex items-center justify-center border border-white/10">
          {predictedText ? (
            <p className="text-3xl md:text-4xl font-semibold text-primary text-center animate-fade-in-up" data-testid="text-prediction">
              {predictedText}
            </p>
          ) : (
            <p className="text-muted-foreground text-center">
              {isActive ? "Listening..." : "Start webcam to see predictions"}
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}

import { CheckCircle2, Loader2, XCircle, Circle } from "lucide-react";

type Status = "idle" | "training" | "ready" | "error" | "processing";

interface StatusIndicatorProps {
  status: Status;
  message?: string;
}

export function StatusIndicator({ status, message }: StatusIndicatorProps) {
  const getStatusConfig = () => {
    switch (status) {
      case "training":
        return {
          icon: Loader2,
          text: message || "Training in progress...",
          color: "text-primary",
          bgColor: "bg-primary/10",
          animate: "animate-spin",
        };
      case "ready":
        return {
          icon: CheckCircle2,
          text: message || "Model Ready",
          color: "text-chart-2",
          bgColor: "bg-chart-2/10",
          animate: "",
        };
      case "error":
        return {
          icon: XCircle,
          text: message || "Error occurred",
          color: "text-destructive",
          bgColor: "bg-destructive/10",
          animate: "",
        };
      case "processing":
        return {
          icon: Loader2,
          text: message || "Processing...",
          color: "text-chart-3",
          bgColor: "bg-chart-3/10",
          animate: "animate-spin",
        };
      default:
        return {
          icon: Circle,
          text: message || "Idle",
          color: "text-muted-foreground",
          bgColor: "bg-muted",
          animate: "",
        };
    }
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  return (
    <div className="flex items-center gap-3" data-testid={`status-${status}`}>
      <div className={`p-2 rounded-lg ${config.bgColor}`}>
        <Icon className={`w-5 h-5 ${config.color} ${config.animate}`} />
      </div>
      <span className="text-sm font-medium text-foreground">{config.text}</span>
    </div>
  );
}

# AI Lip Reading Application

## Overview

This is a full-stack AI lip reading application that uses deep learning (CNN+BiLSTM) to recognize speech from video input. The application provides real-time webcam-based lip reading, custom model training capabilities, and video analysis features. Users can upload training datasets, preprocess data, train custom models, and perform lip reading inference on both live webcam feeds and uploaded videos.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (October 8, 2025)

### Completed Features
- ✅ **Dataset Upload System**: ZIP file upload with automatic extraction (videos/ and align/ folders)
- ✅ **Automated Preprocessing**: Mediapipe-based face detection and mouth region extraction
- ✅ **CNN+BiLSTM Model**: Deep learning architecture for lip reading with TensorFlow/Keras
- ✅ **Real-time Webcam Prediction**: Live video feed with WebSocket-based text predictions
- ✅ **Video Analysis**: Upload videos for offline lip reading analysis
- ✅ **Progress Tracking**: Real-time training metrics via WebSocket (epochs, loss, accuracy)
- ✅ **Model Persistence**: Save/load models, download to device
- ✅ **Error Handling**: Robust error detection in Python bridge and training pipeline
- ✅ **Demo Mode**: Quick testing without training data

### Implementation Details
- **Backend**: Express.js with WebSocket server, Python bridge for ML operations
- **ML Pipeline**: server/ml_service.py (Mediapipe + TensorFlow) and server/python_bridge.py
- **Frontend**: React with WebSocket connection, webcam capture, file upload
- **Workflow**: Upload dataset → Preprocess → Train → Webcam/Video prediction

## System Architecture

### Frontend Architecture

**Framework & Tooling**
- **React** with TypeScript for type-safe component development
- **Vite** as the build tool and development server
- **Wouter** for lightweight client-side routing
- **TanStack Query** (React Query) for server state management and API caching

**UI/UX Design System**
- **Shadcn/ui** component library with Radix UI primitives for accessible, customizable components
- **Tailwind CSS** for utility-first styling with custom design tokens
- **Dark mode primary** with light mode support via ThemeProvider context
- Design inspired by Linear's minimalism, Hugging Face's AI aesthetics, and Runway ML's gradients
- Custom color palette with AI-focused accent colors (AI Blue, Success Green, Processing Amber)
- Typography: Inter for UI, JetBrains Mono for code/metrics

**State Management Patterns**
- React Query for asynchronous server state
- Local React state (useState/useRef) for UI interactions
- WebSocket connection for real-time training progress and predictions
- Context API for theme management

### Backend Architecture

**Server Framework**
- **Express.js** (Node.js) as the primary HTTP server
- **TypeScript** for type safety across the backend
- **WebSocket (ws)** for real-time bidirectional communication

**Python Integration**
- **Python bridge** using child process spawning to interface with ML services
- **FastAPI-style architecture** (implemented in Python) for ML endpoints
- Machine learning stack: TensorFlow/Keras, OpenCV, Mediapipe, NumPy

**API Structure**
- RESTful endpoints for dataset upload, preprocessing, and training
- WebSocket endpoint (`/ws`) for real-time progress updates and video frame streaming
- File upload handling with Multer middleware
- Python service calls via JSON-based IPC (Inter-Process Communication)

**ML Pipeline Components**
1. **Preprocessing**: Mediapipe face mesh for mouth region extraction
2. **Model Architecture**: CNN+BiLSTM for sequence-to-sequence lip reading
3. **Training**: Custom training loop with epoch-based progress reporting
4. **Inference**: Real-time prediction on video frames or uploaded videos

### Data Storage Solutions

**In-Memory Storage**
- User management via in-memory Map structure (MemStorage class)
- Session state stored in memory during development

**Database Schema (PostgreSQL with Drizzle ORM)**
- Configured for Neon Database serverless PostgreSQL
- Simple user schema with UUID primary keys
- Drizzle Kit for schema migrations

**File Storage**
- `/uploads` - Temporary storage for uploaded datasets and video frames
- `/models` - Persistent storage for trained model weights (.h5 files)
- `/dataset` - User-uploaded training data (videos and alignment files)

### Authentication and Authorization

**Current Implementation**
- Basic user schema with username/password fields
- Session management prepared but minimal authentication flow
- No JWT or OAuth implementation (authentication is basic/placeholder)

**Future Considerations**
- The schema supports user-based model isolation
- Prepared for session-based or token-based auth expansion

## External Dependencies

### Third-Party Services

**Database**
- **Neon Database** - Serverless PostgreSQL database (via `@neondatabase/serverless`)
- Connection string via `DATABASE_URL` environment variable

**Potential Cloud Integrations** (UI prepared, not implemented)
- Google Drive API for model backup (UI button present)
- Replit storage for model persistence (UI button present)

### Key NPM Packages

**Frontend Libraries**
- `@tanstack/react-query` - Server state management
- `@radix-ui/*` - Headless UI component primitives
- `wouter` - Lightweight routing
- `react-hook-form` with `@hookform/resolvers` - Form handling
- `zod` - Schema validation
- `tailwindcss` - Utility-first CSS framework
- `class-variance-authority` & `clsx` - Dynamic className utilities

**Backend Libraries**
- `express` - Web server framework
- `ws` - WebSocket implementation
- `multer` - File upload middleware
- `drizzle-orm` - TypeScript ORM for PostgreSQL
- `adm-zip` - ZIP file extraction for dataset uploads

### Python Dependencies (ML Services)

**Computer Vision & ML**
- `tensorflow`/`keras` - Deep learning framework
- `opencv-python` (cv2) - Video processing
- `mediapipe` - Face mesh and mouth region detection
- `numpy` - Numerical computations

**Development Tools**
- `tsx` - TypeScript execution for Node.js
- `esbuild` - JavaScript bundler for production builds
- `drizzle-kit` - Database migration tool

### Build & Deployment Configuration

**Development**
- Vite dev server with HMR
- Express middleware mode for API proxying
- Replit-specific plugins (cartographer, dev banner, runtime error overlay)

**Production**
- Vite builds to `dist/public`
- ESBuild bundles server code to `dist/index.js`
- Static file serving from Express in production mode